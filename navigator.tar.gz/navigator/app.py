"""NAVigator: Indian mutual funds compared on their actual NAV history.

    streamlit run app.py
"""
import re
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from navigator import data, metrics, simulate
from navigator.fmt import inr, pct

HERE = Path(__file__).resolve().parent

# Categorical colours, checked for colour-blind separation in this order. A fund
# keeps its colour for as long as it stays in the comparison.
COLOURS = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300"]
INK, MUTED, GRID, AXIS = "#0b0b0b", "#898781", "#e1e0d9", "#c3c2b7"
DEFAULT_FUNDS = [122639, 118955, 120716]  # Parag Parikh Flexi Cap, HDFC Flexi Cap, UTI Nifty 50 Index (Direct)
WINDOWS = {"3 years": 3, "5 years": 5, "10 years": 10, "All common history": None}
SOURCE = "NAVs published by AMFI, via mfapi.in."

st.set_page_config(page_title="NAVigator", layout="wide")


@st.cache_data(ttl=24 * 3600, show_spinner="Loading the list of schemes…")
def load_schemes():
    return data.scheme_list()


@st.cache_data(ttl=6 * 3600, show_spinner=False)
def load_nav(code):
    return data.fetch_nav(code)


def label(code):
    return data.short_name(NAMES.get(code, str(code)))


def fdate(d):
    return f"{d.day} {d:%b %Y}"


def colour(code):
    return st.session_state.colour[code]


def add_fund(code):
    taken = {st.session_state.colour[c] for c in st.session_state.funds}
    st.session_state.colour[code] = next(c for c in COLOURS if c not in taken)
    st.session_state.funds.append(code)


def styled(fig, y_title, tickformat=None, log=False, height=430):
    fig.update_layout(
        template="simple_white", height=height, margin=dict(l=0, r=10, t=40, b=0),
        font=dict(family="system-ui, -apple-system, 'Segoe UI', sans-serif", size=13, color=INK),
        hovermode="x unified", legend=dict(orientation="h", y=1.02, yanchor="bottom", x=0, title=None),
        paper_bgcolor="white", plot_bgcolor="white",
    )
    fig.update_xaxes(showgrid=False, linecolor=AXIS, tickcolor=AXIS)
    fig.update_yaxes(title=y_title, tickformat=tickformat, type="log" if log else "linear",
                     showgrid=True, gridcolor=GRID, linecolor=AXIS, tickcolor=AXIS, zeroline=False)
    return fig


def show(fig):
    st.plotly_chart(fig, theme=None, config={"displaylogo": False, "modeBarButtonsToRemove": ["select2d", "lasso2d"]})


def lines(series, y_title, tickformat, hover, log=False, customdata=None):
    fig = go.Figure()
    for code, s in series.items():
        fig.add_trace(go.Scatter(x=s.index, y=s.to_numpy(), mode="lines", name=label(code),
                                 line=dict(color=colour(code), width=2), hovertemplate=hover,
                                 customdata=customdata[code] if customdata else None))
    return styled(fig, y_title, tickformat, log)


def table(df, fmt):
    st.table(df.style.format(fmt), border="horizontal")


def by_fund(func):
    """Apply `func(nav)` to every fund in the comparison; rows are fund labels."""
    return pd.DataFrame({label(c): func(n) for c, n in NAVS.items()}).T


def equity_oriented(meta):
    cat, name = meta.get("scheme_category", "").lower(), meta.get("scheme_name", "").lower()
    if cat.startswith("equity scheme"):
        return True
    return "index" in cat and bool(re.search(r"nifty|sensex", name)) and not re.search(
        r"g-sec|gilt|sdl|bond|psu|debt|gold|silver|nasdaq|s&p|global|us ", name)


def render_markdown(path, demote=0):
    """st.markdown can't load local images, so draw image lines with st.image instead.

    `demote` pushes headings down a level or two so a document fits inside a tab.
    """
    chunk = []
    for line in path.read_text(encoding="utf-8").splitlines():
        img = re.match(r"!\[(.*)\]\((.+)\)\s*$", line.strip())
        if img:
            st.markdown("\n".join(chunk))
            chunk = []
            st.image(str(path.parent / img.group(2)), caption=img.group(1))
        else:
            chunk.append("#" * demote + line if line.startswith("#") else line)
    st.markdown("\n".join(chunk))


# --- Funds ------------------------------------------------------------------

try:
    SCHEMES = load_schemes()
except Exception as exc:
    st.error(f"Could not reach mfapi.in to load the scheme list ({exc}). Try again in a minute.")
    st.stop()
NAMES = dict(zip(SCHEMES["code"], SCHEMES["name"]))

if "funds" not in st.session_state:
    st.session_state.funds = [c for c in DEFAULT_FUNDS if c in NAMES]
    st.session_state.colour = {c: COLOURS[i] for i, c in enumerate(st.session_state.funds)}

with st.sidebar:
    st.subheader("Funds")
    query = st.text_input("Search schemes", placeholder="e.g. nifty 50 index direct")
    if query:
        hits = data.search(SCHEMES, query)
        if hits.empty:
            st.caption("No active growth-option scheme matches that.")
        else:
            pick = st.selectbox("Matches", hits["code"].tolist(), format_func=NAMES.get)
            full = len(st.session_state.funds) >= len(COLOURS)
            if st.button("Add to comparison", disabled=full or pick in st.session_state.funds):
                add_fund(pick)
            if full:
                st.caption(f"Up to {len(COLOURS)} funds at a time; remove one first.")
    kept = st.multiselect("In the comparison", st.session_state.funds,
                          default=st.session_state.funds, format_func=label)
    if kept != st.session_state.funds:
        st.session_state.funds = kept

    st.subheader("Window")
    window = st.radio("Analysis window", list(WINDOWS), index=2, label_visibility="collapsed")
    rf = st.number_input("Risk-free rate, % a year", 0.0, 15.0, 6.0, 0.25,
                         help="Used for Sharpe and Sortino ratios and as the hurdle in rolling returns.") / 100

NAVS, METAS = {}, {}
for code in st.session_state.funds:
    try:
        METAS[code], NAVS[code] = load_nav(code)
    except Exception as exc:
        st.warning(f"Could not load {NAMES.get(code, code)}: {exc}")

st.title("NAVigator")
st.caption("Indian mutual funds compared on their published NAV history: returns, risk, SIP outcomes after "
           "tax, and the cost of Regular plans. For study, not investment advice.")

if not NAVS:
    st.info("Add a fund from the sidebar to begin.")
    st.stop()

common_start = max(n.index[0] for n in NAVS.values())
end = min(n.index[-1] for n in NAVS.values())
years = WINDOWS[window]
start = max(common_start, end - pd.DateOffset(years=years)) if years else common_start
start = NAVS[next(iter(NAVS))].loc[start:].index[0]
span = (end - start).days / 365

note = f"Window: {fdate(start)} to {fdate(end)} ({span:.1f} years)."
if years and span < years - 0.01:
    note += f" The funds only have common history from {fdate(common_start)}, so this is shorter than {years} years."
st.markdown(note)

tabs = st.tabs(["Returns", "Rolling returns", "Drawdowns", "SIP / lump sum", "Direct vs Regular",
                "Research note", "Data & method"])

# --- Returns ----------------------------------------------------------------

with tabs[0]:
    log = st.checkbox("Log scale", help="On a log scale equal slopes mean equal rates of growth.")
    indexed = {c: metrics.growth_of(n.loc[start:end], 100) for c, n in NAVS.items()}
    show(lines(indexed, "Value of 100 invested at the start", ",.0f", "%{y:,.1f}", log=log))
    st.caption(SOURCE + " Growth option NAVs already include reinvested income and are net of the expense ratio.")

    st.markdown(f"**Trailing returns to {fdate(end)}** (annualised)")
    trailing = by_fund(lambda n: metrics.trailing_returns(n.loc[:end]))
    table(trailing, pct)
    st.caption("'Full history' starts from the first NAV mfapi.in has for the plan. For Direct plans that is "
               "January 2013 at the earliest, when Direct plans were introduced.")

    st.markdown("**Return and risk over the window**")
    risk = by_fund(lambda n: pd.concat([
        pd.Series({"CAGR": metrics.cagr(n, start, end)}),
        metrics.risk_stats(n.loc[start:end], rf),
        pd.Series({"Max drawdown": metrics.drawdown(n.loc[start:end]).min()}),
    ]))
    ratio_fmt = lambda x: "–" if pd.isna(x) else f"{x:.2f}"
    table(risk, {"CAGR": pct, "Volatility": pct, "Max drawdown": pct, "Sharpe": ratio_fmt, "Sortino": ratio_fmt})
    st.caption(f"Volatility, Sharpe and Sortino use monthly returns; risk-free rate {pct(rf, 2)} a year.")

    st.markdown("**Calendar-year returns**")
    yearly = pd.DataFrame({label(c): metrics.calendar_year_returns(n.loc[start:end]) for c, n in NAVS.items()})
    unfinished = (end.month, end.day) < (12, 28)
    yearly.index = [f"{y} (to {end.day} {end:%b})" if y == end.year and unfinished else str(y) for y in yearly.index]
    table(yearly, pct)

# --- Rolling returns --------------------------------------------------------

with tabs[1]:
    n_years = st.segmented_control("Holding period", [1, 3, 5, 7], default=3,
                                   format_func=lambda y: f"{y} year" + ("s" if y > 1 else "")) or 3
    rolling = {c: metrics.rolling_cagr(n.loc[start:end], n_years) for c, n in NAVS.items()}
    if all(r.empty for r in rolling.values()):
        st.info(f"The window is shorter than {n_years} years. Pick a longer window in the sidebar.")
    else:
        fig = lines(rolling, f"Annualised return over the previous {n_years} years", ".0%", "%{y:.1%}")
        fig.add_hline(y=rf, line=dict(color=MUTED, width=1, dash="dot"),
                      annotation_text=f"risk-free {pct(rf, 1)}", annotation_position="bottom right",
                      annotation_font_color=MUTED)
        show(fig)
        summary = by_fund(lambda n: metrics.rolling_summary(metrics.rolling_cagr(n.loc[start:end], n_years), rf))
        table(summary, {"Windows": "{:,.0f}".format, "Median": pct, "Worst": pct, "Best": pct,
                        "Below 0%": lambda x: pct(x, 1), "Below risk-free": lambda x: pct(x, 1)})
        st.caption(f"Each point is the return of a {n_years}-year holding period ending on that day. The periods "
                   "overlap heavily, so the shares in the table are not independent observations.")

# --- Drawdowns --------------------------------------------------------------

with tabs[2]:
    dd = {c: metrics.drawdown(n.loc[start:end]) for c, n in NAVS.items()}
    show(lines(dd, "Fall from previous peak", ".0%", "%{y:.1%}"))
    st.caption("Drawdown: how far the NAV is below its highest value so far in the window.")

    current = by_fund(lambda n: pd.Series({
        "Max drawdown": metrics.drawdown(n.loc[start:end]).min(),
        "Below peak now": metrics.drawdown(n.loc[start:end]).iloc[-1],
    }))
    table(current, pct)

    pick = st.selectbox("Deepest falls for", list(NAVS), format_func=label)
    worst = metrics.worst_drawdowns(NAVS[pick].loc[start:end])
    if worst.empty:
        st.write("No fall from a peak in this window.")
    else:
        worst.index = range(1, len(worst) + 1)
        date = lambda d: "not yet" if pd.isna(d) else fdate(d)
        days = lambda d: "–" if pd.isna(d) else f"{d:,.0f}"
        table(worst, {"Peak": date, "Trough": date, "Recovered": date, "Depth": pct,
                      "Days to trough": days, "Days to recover": days})

# --- SIP / lump sum ---------------------------------------------------------

with tabs[3]:
    c1, c2, c3, c4 = st.columns(4)
    mode = c1.segmented_control("Investment", ["Monthly SIP", "Lump sum"], default="Monthly SIP") or "Monthly SIP"
    amount = c2.number_input("Amount, ₹", 500, 10_000_000, 10_000 if mode == "Monthly SIP" else 100_000, 500)
    sip_start = pd.Timestamp(c3.date_input("From", start, min_value=common_start, max_value=end, format="DD/MM/YYYY"))
    sip_end = pd.Timestamp(c4.date_input("Redeem on", end, min_value=common_start, max_value=end, format="DD/MM/YYYY"))
    c1, c2, c3, c4 = st.columns(4)
    day = c1.number_input("SIP day of month", 1, 31, 5, disabled=mode != "Monthly SIP")
    load = c2.number_input("Exit load, %", 0.0, 5.0, 1.0, 0.25) / 100
    load_days = c3.number_input("if redeemed within (days)", 0, 1095, 365, 1)
    taxed = c4.checkbox("Apply capital gains tax", value=True,
                        help="Equity-oriented fund rules for a resident individual. See 'Data & method'.")

    if sip_end <= sip_start:
        st.warning("The redemption date has to be after the start date.")
    else:
        results, paths, working = {}, {}, {}
        for c, n in NAVS.items():
            lots = (simulate.sip_lots(n, amount, sip_start, sip_end, day) if mode == "Monthly SIP"
                    else simulate.lumpsum_lots(n, amount, sip_start))
            if lots.empty:
                continue
            res = simulate.outcome(n, lots, sip_end, load, load_days)
            red = res["redemption"]
            after = res["post_tax_value"] if taxed else red["gross_value"] - red["exit_load"] - red["stt"]
            results[label(c)] = {
                "Invested": res["invested"], "Value": res["value"], "XIRR": res["xirr"],
                "Exit load": red["exit_load"], "Tax": res["tax"] if taxed else 0.0,
                "In hand": after,
                "XIRR in hand": simulate.xirr(list(lots["date"]) + [red["date"]], list(-lots["amount"]) + [after]),
            }
            working[label(c)] = {
                "Redemption value": red["gross_value"], "Exit load": red["exit_load"],
                "Short-term gain": red["short_term_gain"], "Long-term gain": red["long_term_gain"],
                "Exemption used": red["exemption_used"], "Tax incl. cess": red["tax"], "STT": red["stt"],
            }
            paths[c] = simulate.value_path(n, lots, sip_end)

        if results:
            fig = go.Figure()
            first = next(iter(paths.values()))
            fig.add_trace(go.Scatter(x=first.index, y=first["invested"] / 1e5, name="Amount invested",
                                     line=dict(color=MUTED, width=1.5), customdata=first["invested"].map(inr),
                                     hovertemplate="%{customdata}"))
            for c, p in paths.items():
                fig.add_trace(go.Scatter(x=p.index, y=p["value"] / 1e5, name=label(c), mode="lines",
                                         line=dict(color=colour(c), width=2), customdata=p["value"].map(inr),
                                         hovertemplate="%{customdata}"))
            show(styled(fig, "Value, ₹ lakh", ",.1f"))

            money = {k: inr for k in ["Invested", "Value", "Exit load", "Tax", "In hand"]}
            table(pd.DataFrame(results).T, money | {"XIRR": pct, "XIRR in hand": pct})
            st.caption("'In hand' is what reaches the bank account after exit load, STT and (if ticked) tax. "
                       "Stamp duty of 0.005% is deducted from purchases made from July 2020.")

            not_equity = [label(c) for c in NAVS if not equity_oriented(METAS[c])]
            if taxed and not_equity:
                st.warning("Tax is worked out with equity-fund rules. Check that these schemes keep at least 65% "
                           "in Indian equity before relying on it: " + ", ".join(not_equity))

            with st.expander("How the tax was worked out"):
                table(pd.DataFrame(working), lambda x: inr(x, 2) if 0 < abs(x) < 100 else inr(x))
                st.caption("Units held more than 12 months are long-term. A short-term loss is set off against "
                           "long-term gains. Assumes no other capital gains that year, no surcharge and no "
                           "brought-forward losses.")

# --- Direct vs Regular ------------------------------------------------------

with tabs[4]:
    st.write("Both plans of a scheme hold the same portfolio. The Regular plan charges a higher expense ratio "
             "because it pays the distributor a commission, so the gap between the two NAVs measures that cost.")
    pick = st.selectbox("Scheme", list(NAVS), format_func=label, key="dvr_pick")
    other = data.other_plan(SCHEMES, pick)
    if other is None:
        st.info("Couldn't find a single matching plan for this scheme in the list of active schemes.")
    else:
        direct, regular = (pick, other) if data.plan_of(NAMES[pick]) == "Direct" else (other, pick)
        _, d = load_nav(direct)
        _, r = load_nav(regular)
        both = d.index.intersection(r.index)
        d, r = d.loc[both], r.loc[both]

        gap = pd.DataFrame({
            "Direct": metrics.trailing_returns(d),
            "Regular": metrics.trailing_returns(r),
        })
        gap["Gap"] = gap["Direct"] - gap["Regular"]
        gap = gap.dropna().T
        gap.columns = [c.replace("Full history", f"Since {both[0]:%b %Y}") for c in gap.columns]
        table(gap, pct)

        ratio = d / r
        ratio = ratio / ratio.iloc[0]
        yrs = (both[-1] - both[0]).days / 365
        implied = ratio.iloc[-1] ** (1 / yrs) - 1
        fig = go.Figure(go.Scatter(x=ratio.index, y=ratio.to_numpy(), mode="lines", name="Direct ÷ Regular",
                                   line=dict(color=COLOURS[0], width=2), hovertemplate="%{y:.4f}"))
        show(styled(fig, f"Direct NAV ÷ Regular NAV ({both[0]:%b %Y} = 1)", ".3f", height=360))
        st.caption(f"The ratio rises steadily because the cost difference compounds. Its slope works out to "
                   f"{pct(implied)} a year over {yrs:.1f} years, which is the effective extra cost of the Regular "
                   f"plan. The gap in returns in the table is a little larger than this, because the extra cost is "
                   f"taken out of a balance that keeps growing: roughly cost × (1 + return).")

        st.markdown("**What it means for a SIP**")
        c1, c2 = st.columns(2)
        sip_amt = c1.number_input("Monthly SIP, ₹", 500, 1_000_000, 10_000, 500, key="dvr_amt")
        max_years = int(yrs)
        if max_years >= 2:
            sip_years = c2.slider("Years", 1, max_years, min(10, max_years), key="dvr_years")
        else:
            sip_years = 1
            c2.caption("Less than two years of common history, so the example uses one year.")
        s_from = both[-1] - pd.DateOffset(years=sip_years)
        val = {}
        for name, n in [("Direct", d), ("Regular", r)]:
            lots = simulate.sip_lots(n, sip_amt, s_from, both[-1], day=5)
            val[name] = simulate.outcome(n, lots, both[-1])
        lost = val["Direct"]["value"] - val["Regular"]["value"]
        st.write(
            f"A {inr(sip_amt)} monthly SIP from {s_from:%b %Y} to {both[-1]:%b %Y} ({inr(val['Direct']['invested'])} "
            f"invested) would be worth **{inr(val['Direct']['value'])}** in the Direct plan and "
            f"**{inr(val['Regular']['value'])}** in the Regular plan: {inr(lost)} less, before tax "
            f"(XIRR {pct(val['Direct']['xirr'])} vs {pct(val['Regular']['xirr'])})."
        )

# --- Research note ----------------------------------------------------------

with tabs[5]:
    render_markdown(HERE / "research" / "direct-vs-regular.md", demote=2)

# --- Data & method ----------------------------------------------------------

with tabs[6]:
    st.markdown("**Data used in this comparison**")
    rows = {}
    for c, n in NAVS.items():
        chk = data.data_checks(n)
        rows[label(c)] = {
            "Scheme code": str(c),
            "Fund house": METAS[c].get("fund_house", ""),
            "Category": METAS[c].get("scheme_category", ""),
            "First NAV": fdate(chk["first_nav"]),
            "Last NAV": fdate(chk["last_nav"]),
            "NAVs": f"{chk['nav_count']:,}",
            "Longest gap (days)": str(chk["longest_gap_days"]),
            "Daily moves over 15%": str(len(chk["big_moves"])),
        }
    st.table(pd.DataFrame(rows).T, border="horizontal")
    st.caption("A gap of a few days is normal around weekends and market holidays. A daily move over 15% in a "
               "diversified fund is more likely a data error than a real price change, and would distort the "
               "numbers.")
    render_markdown(HERE / "docs" / "methodology.md", demote=1)
