import numpy as np
import pandas as pd
import pytest

from navigator import metrics


def test_cagr_of_steady_growth(steady):
    nav = steady(0.10)
    assert metrics.cagr(nav, nav.index[0], nav.index[-1]) == pytest.approx(0.10)


def test_cagr_needs_enough_history(steady):
    nav = steady(0.10, start="2018-01-01")
    assert np.isnan(metrics.cagr(nav, "2015-01-01", nav.index[-1]))


def test_trailing_and_rolling_returns_of_steady_growth(steady):
    nav = steady(0.10)
    trailing = metrics.trailing_returns(nav, periods=(1, 3, 5))
    # Start dates that fall on a weekend use Friday's NAV, so allow a small error.
    assert trailing.to_numpy() == pytest.approx([0.10] * 4, abs=1e-3)
    roll = metrics.rolling_cagr(nav, 3)
    assert roll.index[0] >= nav.index[0] + pd.DateOffset(years=3)
    assert roll.min() == pytest.approx(0.10, abs=1e-3)
    assert roll.max() == pytest.approx(0.10, abs=1e-3)


def test_worst_drawdowns():
    idx = pd.date_range("2020-01-01", periods=8, freq="D")
    nav = pd.Series([100, 120, 90, 110, 125, 100, 110, 115], index=idx, dtype=float)
    table = metrics.worst_drawdowns(nav)

    first = table.iloc[0]
    assert first["Depth"] == pytest.approx(-0.25)
    assert (first["Peak"], first["Trough"], first["Recovered"]) == (idx[1], idx[2], idx[4])

    second = table.iloc[1]
    assert second["Depth"] == pytest.approx(-0.20)
    assert pd.isna(second["Recovered"])


def test_no_drawdown_on_a_rising_series(steady):
    assert metrics.worst_drawdowns(steady(0.08)).empty


def test_monthly_returns_leave_out_unfinished_month():
    idx = pd.bdate_range("2021-01-01", "2021-04-05")
    nav = pd.Series(np.linspace(100, 110, len(idx)), index=idx)
    assert list(metrics.monthly_returns(nav).index.month) == [2, 3]


def test_sharpe_and_sortino_by_hand():
    monthly = np.array([0.02, -0.01, 0.03, 0.0, 0.01, -0.02, 0.04, 0.01, -0.01, 0.02, 0.01, 0.0])
    idx = pd.date_range("2019-12-31", periods=13, freq="ME")
    nav = pd.Series(100 * np.concatenate([[1], np.cumprod(1 + monthly)]), index=idx)

    stats = metrics.risk_stats(nav, rf=0.0)
    assert stats["Volatility"] == pytest.approx(monthly.std(ddof=1) * np.sqrt(12))
    assert stats["Sharpe"] == pytest.approx(monthly.mean() / monthly.std(ddof=1) * np.sqrt(12))
    downside = np.sqrt(np.mean(np.minimum(monthly, 0) ** 2) * 12)
    assert stats["Sortino"] == pytest.approx(monthly.mean() * 12 / downside)


def test_calendar_year_returns():
    nav = pd.Series([100.0, 105.0, 110.0, 99.0],
                    index=pd.to_datetime(["2019-12-31", "2020-06-30", "2020-12-31", "2021-12-31"]))
    rets = metrics.calendar_year_returns(nav)
    assert rets.to_dict() == pytest.approx({2020: 0.10, 2021: -0.10})
