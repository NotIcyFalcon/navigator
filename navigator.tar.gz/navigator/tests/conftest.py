import pandas as pd
import pytest


@pytest.fixture
def steady():
    """Business-day NAVs growing at exactly `rate` a year (365-day convention)."""
    def make(rate=0.10, start="2010-01-01", end="2020-12-31"):
        idx = pd.bdate_range(start, end)
        days = (idx - idx[0]).days.to_numpy()
        return pd.Series(10 * (1 + rate) ** (days / 365), index=idx)
    return make
