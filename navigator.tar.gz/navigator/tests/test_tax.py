import pandas as pd
import pytest

from navigator import tax


def series(points):
    s = pd.Series(points, dtype=float)
    s.index = pd.to_datetime(s.index)
    return s.sort_index()


def lots(*rows):
    df = pd.DataFrame(rows, columns=["date", "amount", "units"])
    df["date"] = pd.to_datetime(df["date"])
    return df


def test_long_term_gain_within_exemption_is_not_taxed():
    nav = series({"2022-01-03": 10, "2025-06-02": 15})
    res = tax.redeem(lots(("2022-01-03", 100_000, 10_000)), nav, "2025-06-02")
    assert res["long_term_gain"] == pytest.approx(50_000)
    assert res["tax"] == 0
    assert res["net_proceeds"] == pytest.approx(150_000 - 1.5)  # STT 0.001%


def test_long_term_gain_above_exemption():
    nav = series({"2022-01-03": 10, "2025-06-02": 15})
    res = tax.redeem(lots(("2022-01-03", 500_000, 50_000)), nav, "2025-06-02")
    # (2,50,000 - 1,25,000) x 12.5%, plus 4% cess
    assert res["tax"] == pytest.approx(16_250)


def test_short_term_gain_with_exit_load():
    nav = series({"2025-01-01": 10, "2025-06-02": 12})
    res = tax.redeem(lots(("2025-01-01", 100_000, 10_000)), nav, "2025-06-02", exit_load=0.01)
    assert res["exit_load"] == pytest.approx(1_200)
    assert res["short_term_gain"] == pytest.approx(18_800)
    assert res["tax"] == pytest.approx(18_800 * 0.20 * 1.04)


def test_units_bought_before_feb_2018_are_grandfathered():
    nav = series({"2017-06-01": 50, "2018-01-31": 60, "2025-06-02": 200})
    res = tax.redeem(lots(("2017-06-01", 50_000, 1_000)), nav, "2025-06-02")
    # Cost is lifted from 50,000 to the 31 Jan 2018 value of 60,000.
    assert res["long_term_gain"] == pytest.approx(140_000)
    assert res["tax"] == pytest.approx(15_000 * 0.125 * 1.04)


def test_rates_change_on_23_july_2024():
    nav = series({"2021-01-01": 10, "2024-07-22": 32.5, "2024-07-23": 32.5})
    held = lots(("2021-01-01", 100_000, 10_000))  # long-term gain of 2,25,000
    assert tax.redeem(held, nav, "2024-07-22")["tax"] == pytest.approx(100_000 * 0.10 * 1.04)
    assert tax.redeem(held, nav, "2024-07-23")["tax"] == pytest.approx(100_000 * 0.125 * 1.04)


def test_short_term_loss_is_set_off_against_long_term_gain():
    nav = series({"2020-01-01": 10, "2025-01-01": 25, "2025-06-02": 20})
    held = lots(("2020-01-01", 300_000, 30_000), ("2025-01-01", 250_000, 10_000))
    res = tax.redeem(held, nav, "2025-06-02")
    assert res["short_term_gain"] == 0
    assert res["long_term_gain"] == pytest.approx(250_000)
    assert res["tax"] == pytest.approx(125_000 * 0.125 * 1.04)


def test_rules_before_2008_are_not_modelled():
    with pytest.raises(ValueError):
        tax.rules_on("2007-12-31")
