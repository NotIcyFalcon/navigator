import pandas as pd
import pytest

from navigator import metrics, simulate


def test_xirr_matches_excel_documentation_example():
    dates = ["2008-01-01", "2008-03-01", "2008-10-30", "2009-02-15", "2009-04-01"]
    flows = [-10000, 2750, 4250, 3250, 2750]
    assert simulate.xirr(dates, flows) == pytest.approx(0.373362535, abs=1e-6)


def test_lumpsum_xirr_equals_cagr(steady):
    nav = steady(0.12, "2012-01-02", "2019-12-31")
    lots = simulate.lumpsum_lots(nav, 100_000, "2012-01-02")
    res = simulate.outcome(nav, lots, nav.index[-1])
    assert res["xirr"] == pytest.approx(metrics.cagr(nav, nav.index[0], nav.index[-1]), abs=1e-7)


def test_sip_dates_move_past_holidays_and_short_months():
    nav = pd.Series(10.0, index=pd.bdate_range("2019-01-01", "2019-04-30"))
    lots = simulate.sip_lots(nav, 5_000, "2019-01-01", "2019-04-30", day=31)
    # 31 Mar 2019 was a Sunday, so that instalment goes in on Monday 1 Apr.
    assert lots["date"].dt.strftime("%Y-%m-%d").tolist() == ["2019-01-31", "2019-02-28", "2019-04-01", "2019-04-30"]


def test_flat_nav_sip_earns_nothing():
    nav = pd.Series(25.0, index=pd.bdate_range("2015-01-01", "2017-12-31"))
    lots = simulate.sip_lots(nav, 1_000, "2015-01-01", "2017-12-31")
    res = simulate.outcome(nav, lots, "2017-12-29")
    assert len(lots) == 36
    assert res["value"] == pytest.approx(res["invested"])
    assert res["xirr"] == pytest.approx(0, abs=1e-9)
    assert res["tax"] == 0


def test_stamp_duty_from_july_2020():
    nav = pd.Series(10.0, index=pd.bdate_range("2020-06-29", "2020-07-03"))
    assert simulate.buy(nav, "2020-06-30", 10_000)["units"] == pytest.approx(1000)
    assert simulate.buy(nav, "2020-07-01", 10_000)["units"] == pytest.approx(999.95)
