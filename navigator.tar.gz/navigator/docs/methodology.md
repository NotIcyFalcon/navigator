## Method

### Data

- NAVs come from [mfapi.in](https://www.mfapi.in/), which republishes the daily NAV file AMFI releases for every scheme. History goes back to April 2006 for older schemes. Direct plans start in January 2013, when they were introduced.
- Only the growth option is used. Its NAV already includes reinvested income and is net of the expense ratio, so returns need no fee adjustment.
- Search lists only schemes that published a NAV in the last 30 days, which leaves out matured and merged schemes.
- On days without a NAV (weekends, holidays) the last NAV published before that day is used.

### Returns

- CAGR = (NAV at end ÷ NAV at start)^(365 ÷ days) − 1. A 365-day year is used everywhere, the same convention as Excel's XIRR, so a lump sum's XIRR and CAGR come out identical.
- Trailing returns run from the same calendar date 1, 3, 5 or 10 years earlier.
- Rolling returns are the CAGR over every N-year period ending on each NAV date in the window. The periods overlap, so "share of periods below 0%" describes the history; it is not a probability.
- Calendar-year returns run from the last NAV of one year to the last NAV of the next.

### Risk

- Monthly returns come from month-end NAVs (the last NAV of each month). A month still in progress at the end of the window is dropped.
- Volatility: standard deviation of monthly returns × √12.
- Sharpe ratio: mean monthly return above the risk-free rate × 12, divided by volatility.
- Sortino ratio: the same numerator divided by downside deviation, √(mean of min(excess return, 0)² × 12).
- The risk-free rate is one annual figure set in the sidebar (default 6%). That is a simplification: 91-day Treasury bill yields moved between roughly 3% and 7% over the last ten years.
- Drawdown: NAV ÷ highest NAV so far − 1. A drawdown episode lasts from a peak until the NAV first gets back to it.

### SIP and lump sum

- One purchase each month on the chosen day. If there is no NAV that day, the next NAV is used, which is how AMCs process holiday instalments. Days 29 to 31 move to the last day of shorter months.
- Stamp duty of 0.005% is deducted from purchases made on or after 1 July 2020.
- Cut-off times and the realisation-of-funds rule for large purchases are ignored.
- XIRR is found by bisection on the net present value of the cash flows.
- Exit load applies to each instalment separately if it is redeemed within the set number of days. The default, 1% within 365 days, is common for equity funds but varies by scheme.

### Tax

Equity-oriented funds, resident individual. The rules are chosen by redemption date.

| Redemption date | Short-term (held ≤ 12 months) | Long-term (held > 12 months) | Long-term exemption a year | Cess | STT on redemption |
|---|---|---|---|---|---|
| Apr 2008 to May 2013 | 15% | exempt | – | 3% | 0.25% |
| Jun 2013 to Mar 2018 | 15% | exempt | – | 3% | 0.001% |
| Apr 2018 to Mar 2024 | 15% | 10% | ₹1,00,000 | 4% | 0.001% |
| 1 Apr to 22 Jul 2024 | 15% | 10% | ₹1,25,000 | 4% | 0.001% |
| From 23 Jul 2024 | 20% | 12.5% | ₹1,25,000 | 4% | 0.001% |

- Each SIP instalment has its own holding period.
- Grandfathering (Finance Act 2018): for units bought before 1 February 2018, the cost used for long-term gains is the higher of the amount paid and the NAV on 31 January 2018, but no more than the sale value.
- A net short-term loss is set off against long-term gains. A long-term loss cannot be set off against short-term gains.
- The ₹1.25 lakh exemption covered the whole of FY 2024-25; the new rates applied only to sales from 23 July 2024.
- Budget 2026 left these rates unchanged, and the Income-tax Act, 2025, in force from 1 April 2026, kept them.
- Assumes no other capital gains in the year (so the whole exemption is available), no surcharge, no brought-forward losses and no rebate under section 87A.
- Debt, gold, international and most hybrid funds are taxed differently and are not modelled. The app warns when a scheme in the comparison doesn't look equity-oriented.
- Sources: Finance Act 2018; Finance (No. 2) Act 2024; the Income Tax Department's FAQs on the 2024 changes; AMC tax reckoners for FY 2026-27.

### Direct vs Regular

- The two plans are paired by name with the plan and option words removed, and only when exactly one match turns up.
- Only dates on which both plans have a NAV are used.
- The ratio Direct NAV ÷ Regular NAV, rebased to 1, grows at about the difference between the two expense ratios. Its annualised growth is reported as the effective extra cost of the Regular plan.

### Limitations

- Everything here is past performance over particular dates. Different start and end dates give different numbers; the rolling returns show how much.
- NAVs are used as published. The data checks flag long gaps and large daily moves, but nothing is corrected.
- Categories come from AMFI and show a scheme's current category. Many schemes changed category or mandate in SEBI's 2017–18 recategorisation, so long histories can mix strategies.
- There is no benchmark index data (index funds can stand in for it), so no alpha or beta.
- Exit loads, the three-year ELSS lock-in and minimum SIP amounts are not checked against each scheme's documents.
