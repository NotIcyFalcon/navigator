"""Tax on redeeming units of an equity-oriented mutual fund, for a resident individual.

Rules are picked by redemption date, so a simulation that ends in 2019 is taxed
under the law of 2019. Sources are listed in docs/methodology.md.
"""
from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class Rules:
    stcg: float            # units held 12 months or less
    ltcg: float            # units held longer than 12 months
    ltcg_exemption: float  # long-term gains exempt each financial year, in rupees
    cess: float            # charged on the tax itself
    stt: float             # on the redemption value


RULES = [  # (applies to redemptions on or after, rules)
    ("2008-04-01", Rules(0.15, 0.0, 0, 0.03, 0.0025)),
    ("2013-06-01", Rules(0.15, 0.0, 0, 0.03, 0.00001)),
    ("2018-04-01", Rules(0.15, 0.10, 100_000, 0.04, 0.00001)),
    ("2024-04-01", Rules(0.15, 0.10, 125_000, 0.04, 0.00001)),  # higher exemption covers all of FY 2024-25
    ("2024-07-23", Rules(0.20, 0.125, 125_000, 0.04, 0.00001)),
]

# Long-term gains on units bought before 1 Feb 2018 are grandfathered: the cost
# is taken as at least the NAV of 31 Jan 2018, capped at the sale value.
GRANDFATHER_BEFORE = pd.Timestamp("2018-02-01")
GRANDFATHER_NAV_DATE = pd.Timestamp("2018-01-31")
LTCG_TAXED_FROM = pd.Timestamp("2018-04-01")


def rules_on(date):
    date = pd.Timestamp(date)
    applicable = [r for start, r in RULES if date >= pd.Timestamp(start)]
    if not applicable:
        raise ValueError("tax rules before April 2008 are not modelled")
    return applicable[-1]


def redeem(lots, nav, on, exit_load=0.0, exit_load_days=365):
    """Redeem every lot on `on` and work out exit load, STT and capital gains tax.

    `lots` needs columns date, amount and units (see simulate.buy). Assumes no
    other capital gains in the year, so the whole exemption is available, and
    no surcharge or brought-forward losses.
    """
    on = pd.Timestamp(on)
    price = float(nav.asof(on))
    rules = rules_on(on)
    nav_2018 = float(nav.asof(GRANDFATHER_NAV_DATE)) if nav.index[0] <= GRANDFATHER_NAV_DATE else np.nan

    st_gain = lt_gain = load_total = 0.0
    for lot in lots.itertuples(index=False):
        value = lot.units * price
        load = value * exit_load if (on - lot.date).days <= exit_load_days else 0.0
        sale = value - load
        cost = lot.amount
        long_term = on > lot.date + pd.DateOffset(months=12)
        if long_term and lot.date < GRANDFATHER_BEFORE and on >= LTCG_TAXED_FROM and not np.isnan(nav_2018):
            cost = max(cost, min(lot.units * nav_2018, sale))
        if long_term:
            lt_gain += sale - cost
        else:
            st_gain += sale - cost
        load_total += load

    # A short-term loss can be set off against long-term gains, but not the other way round.
    if st_gain < 0:
        lt_gain += st_gain
        st_gain = 0.0
    exempt = min(max(lt_gain, 0.0), rules.ltcg_exemption)
    tax = (st_gain * rules.stcg + (max(lt_gain, 0.0) - exempt) * rules.ltcg) * (1 + rules.cess)

    gross = lots["units"].sum() * price
    stt = (gross - load_total) * rules.stt
    return {
        "date": on,
        "gross_value": gross,
        "exit_load": load_total,
        "stt": stt,
        "short_term_gain": st_gain,
        "long_term_gain": lt_gain,
        "exemption_used": exempt,
        "tax": tax,
        "net_proceeds": gross - load_total - stt - tax,
    }
