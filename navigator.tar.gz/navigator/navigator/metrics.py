"""Return and risk measures for a NAV series.

Every function takes a Series of NAVs indexed by date, oldest first. Annual
figures use a 365-day year, the same convention as Excel's XIRR, so that a lump
sum's XIRR and its CAGR come out identical.
"""
import numpy as np
import pandas as pd

DAYS_IN_YEAR = 365


def nav_on(nav, date):
    """NAV on `date`, or the last one published before it (weekends, holidays)."""
    return float(nav.asof(pd.Timestamp(date)))


def cagr(nav, start, end):
    start, end = pd.Timestamp(start), pd.Timestamp(end)
    if start < nav.index[0] or end <= start:
        return np.nan
    years = (end - start).days / DAYS_IN_YEAR
    return (nav_on(nav, end) / nav_on(nav, start)) ** (1 / years) - 1


def trailing_returns(nav, end=None, periods=(1, 3, 5, 10)):
    """Annualised point-to-point returns over the last 1, 3, 5... years to `end`."""
    end = nav.index[-1] if end is None else pd.Timestamp(end)
    out = {f"{y}Y": cagr(nav, end - pd.DateOffset(years=y), end) for y in periods}
    out["Full history"] = cagr(nav, nav.index[0], end)
    return pd.Series(out)


def rolling_cagr(nav, years):
    """Annualised return over every `years`-long window, indexed by the window's last day."""
    starts = nav.index - pd.DateOffset(years=years)
    ok = starts >= nav.index[0]
    if not ok.any():
        return pd.Series(dtype=float)
    start_navs = nav.asof(starts[ok]).to_numpy()
    days = (nav.index[ok] - starts[ok]).days.to_numpy()
    out = (nav.to_numpy()[ok] / start_navs) ** (DAYS_IN_YEAR / days) - 1
    return pd.Series(out, index=nav.index[ok])


def rolling_summary(roll, hurdle=None):
    s = {
        "Windows": len(roll),
        "Median": roll.median(),
        "Worst": roll.min(),
        "Best": roll.max(),
        "Below 0%": (roll < 0).mean(),
    }
    if hurdle is not None:
        s["Below risk-free"] = (roll < hurdle).mean()
    return pd.Series(s)


def monthly_returns(nav):
    """Returns between consecutive month-end NAVs. A month still in progress is left out."""
    month_end = nav.resample("ME").last()
    if nav.index[-1] < month_end.index[-1] - pd.Timedelta(days=4):
        month_end = month_end.iloc[:-1]
    return month_end.pct_change().dropna()


def risk_stats(nav, rf=0.06):
    """Volatility, Sharpe and Sortino from monthly returns. `rf` is an annual rate."""
    r = monthly_returns(nav)
    if len(r) < 12:
        return pd.Series({"Volatility": np.nan, "Sharpe": np.nan, "Sortino": np.nan})
    excess = r - ((1 + rf) ** (1 / 12) - 1)
    vol = r.std() * np.sqrt(12)
    downside = np.sqrt((np.minimum(excess, 0) ** 2).mean() * 12)
    return pd.Series({
        "Volatility": vol,
        "Sharpe": excess.mean() * 12 / vol,
        "Sortino": excess.mean() * 12 / downside if downside > 0 else np.nan,
    })


def drawdown(nav):
    return nav / nav.cummax() - 1


def worst_drawdowns(nav, n=5):
    """The `n` deepest peak-to-trough falls, with dates and recovery times."""
    dd = drawdown(nav)
    under = dd < 0
    episode = (under != under.shift()).cumsum()
    rows = []
    for _, seg in dd[under].groupby(episode[under]):
        first = nav.index.get_loc(seg.index[0])
        last = nav.index.get_loc(seg.index[-1])
        peak, trough = nav.index[first - 1], seg.idxmin()
        recovered = nav.index[last + 1] if last + 1 < len(nav) else pd.NaT
        rows.append({
            "Peak": peak,
            "Trough": trough,
            "Recovered": recovered,
            "Depth": seg.min(),
            "Days to trough": (trough - peak).days,
            "Days to recover": (recovered - trough).days if pd.notna(recovered) else np.nan,
        })
    cols = ["Peak", "Trough", "Recovered", "Depth", "Days to trough", "Days to recover"]
    if not rows:
        return pd.DataFrame(columns=cols)
    return pd.DataFrame(rows, columns=cols).nsmallest(n, "Depth").reset_index(drop=True)


def calendar_year_returns(nav):
    """Return for each calendar year. The latest year is year-to-date if it isn't over."""
    year_end = nav.resample("YE").last()
    rets = year_end.pct_change().dropna()
    rets.index = rets.index.year
    return rets


def growth_of(nav, amount=10_000):
    return nav / nav.iloc[0] * amount
