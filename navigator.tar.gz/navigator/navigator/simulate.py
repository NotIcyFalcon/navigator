"""SIP and lump-sum simulations on real NAVs, and XIRR."""
import numpy as np
import pandas as pd

from . import tax
from .metrics import DAYS_IN_YEAR

# Stamp duty of 0.005% on mutual fund purchases, in force from 1 July 2020.
STAMP_DUTY = 0.00005
STAMP_DUTY_FROM = pd.Timestamp("2020-07-01")


def buy(nav, when, amount):
    """Invest `amount` at the first NAV published on or after `when`."""
    when = pd.Timestamp(when)
    if when < nav.index[0]:
        return None  # the plan didn't exist yet
    i = nav.index.searchsorted(when)
    if i == len(nav):
        return None
    date, price = nav.index[i], float(nav.iloc[i])
    invested = amount * (1 - STAMP_DUTY) if date >= STAMP_DUTY_FROM else amount
    return {"date": date, "amount": amount, "nav": price, "units": invested / price}


def sip_lots(nav, amount, start, end, day=1):
    """Purchase lots for a monthly SIP on `day` of each month from start to end.

    An instalment that falls on a holiday is bought at the next NAV, which is how
    AMCs process it. Days 29-31 move to the last day of shorter months.
    """
    start, end = pd.Timestamp(start), pd.Timestamp(end)
    lots = []
    for month in pd.date_range(start.replace(day=1), end, freq="MS"):
        when = month.replace(day=min(day, month.days_in_month))
        if when < start:
            continue
        lot = buy(nav, when, amount)
        if lot and lot["date"] <= end:
            lots.append(lot)
    return pd.DataFrame(lots, columns=["date", "amount", "nav", "units"])


def lumpsum_lots(nav, amount, when):
    lot = buy(nav, when, amount)
    return pd.DataFrame([lot] if lot else [], columns=["date", "amount", "nav", "units"])


def value_path(nav, lots, end):
    """Market value and cumulative amount invested on every NAV date up to `end`."""
    window = nav.loc[lots["date"].iloc[0]:end]
    held = lots.groupby("date")[["units", "amount"]].sum().reindex(window.index, fill_value=0).cumsum()
    return pd.DataFrame({"value": held["units"] * window, "invested": held["amount"]})


def xirr(dates, amounts):
    """Annual return of irregular cash flows (money in negative, money out positive).

    Found by bisection on the NPV. When all outflows come before all inflows, as
    in a SIP or lump sum held to the end, the NPV falls steadily as the rate rises
    and there is exactly one root.
    """
    t = np.array([(pd.Timestamp(d) - pd.Timestamp(dates[0])).days for d in dates]) / DAYS_IN_YEAR
    a = np.asarray(amounts, dtype=float)

    def npv(rate):
        return np.sum(a / (1 + rate) ** t)

    lo, hi = -0.99, 10.0
    if npv(lo) * npv(hi) > 0:
        return np.nan
    for _ in range(100):
        mid = (lo + hi) / 2
        if npv(lo) * npv(mid) <= 0:
            hi = mid
        else:
            lo = mid
    return (lo + hi) / 2


def outcome(nav, lots, end, exit_load=0.0, exit_load_days=365):
    """What the lots are worth on `end`, before and after exit load and tax, with XIRRs."""
    end = nav.index[nav.index.searchsorted(pd.Timestamp(end), side="right") - 1]
    red = tax.redeem(lots, nav, end, exit_load, exit_load_days)
    dates = list(lots["date"]) + [end]
    flows = list(-lots["amount"])
    return {
        "invested": lots["amount"].sum(),
        "value": red["gross_value"],
        "xirr": xirr(dates, flows + [red["gross_value"]]),
        "tax": red["tax"],
        "post_tax_value": red["net_proceeds"],
        "post_tax_xirr": xirr(dates, flows + [red["net_proceeds"]]),
        "redemption": red,
    }
