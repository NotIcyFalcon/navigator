"""Loading NAV data.

Everything comes from mfapi.in, a free JSON API over the daily NAV file that
AMFI publishes for every mutual fund scheme in India. No key is needed.
"""
import json
import re
import time
from pathlib import Path

import pandas as pd
import requests

API = "https://api.mfapi.in/mf"

# Words that mark a scheme variant as something other than the growth option.
NOT_GROWTH = r"idcw|dividend|bonus|payout|reinvest|segregated|unclaimed"


def get_json(url, retries=3, timeout=60):
    for attempt in range(retries):
        try:
            resp = requests.get(url, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
        except (requests.RequestException, ValueError):
            if attempt == retries - 1:
                raise
            time.sleep(2 * (attempt + 1))


def plan_of(name):
    return "Direct" if re.search(r"\bdirect\b", name, re.I) else "Regular"


def scheme_key(name):
    """Scheme name without plan/option words, so both plans of a scheme share a key."""
    s = re.sub(r"\b(direct|regular|plan|option|growth)\b", " ", name.lower())
    return re.sub(r"[^a-z0-9]", "", s)


def short_name(name):
    """'Parag Parikh Flexi Cap Fund - Direct Plan - Growth' -> 'Parag Parikh Flexi Cap (Direct)'."""
    s = re.sub(r"\(erstwhile[^)]*\)", " ", name, flags=re.I)
    s = re.sub(r"\bfunds?\s+of\s+funds?\b", "FoF", s, flags=re.I)
    s = re.sub(r"\b(direct|regular|plan|growth|option|fund)\b", " ", s, flags=re.I)
    s = re.sub(r"[\s\-.()]+", " ", s).strip()
    return f"{s} ({plan_of(name)})"


def scheme_list(active_days=30):
    """Growth options of every scheme that has published a NAV in the last `active_days` days.

    /mf/latest carries the last NAV date, fund house and SEBI category for each
    scheme, which makes it easy to drop matured and merged schemes.
    """
    df = pd.DataFrame(get_json(f"{API}/latest"))
    df = df.rename(columns={"schemeCode": "code", "schemeName": "name", "fundHouse": "fund_house",
                            "schemeCategory": "category", "date": "last_nav_date"})
    df["last_nav_date"] = pd.to_datetime(df["last_nav_date"], format="%d-%m-%Y", errors="coerce")
    df = df[df["last_nav_date"] >= df["last_nav_date"].max() - pd.Timedelta(days=active_days)]
    df = df[df["name"].str.contains("growth", case=False)
            & ~df["name"].str.contains(NOT_GROWTH, case=False)]
    df = df.assign(plan=df["name"].map(plan_of), key=df["name"].map(scheme_key))
    cols = ["code", "name", "fund_house", "category", "plan", "key", "last_nav_date"]
    return df[cols].reset_index(drop=True)


def search(schemes, query, limit=30):
    """Schemes whose name contains every word of `query`.

    Names containing the query as a phrase come first, then shorter names, so
    "axis small cap" lists Axis Small Cap Fund before Axis Nifty Smallcap 50 Index Fund.
    """
    words = query.lower().split()
    names = schemes["name"].str.lower()
    mask = pd.Series(True, index=schemes.index)
    for word in words:
        mask &= names.str.contains(word, regex=False)
    phrase = " ".join(w for w in words if w not in {"direct", "regular", "plan", "growth", "fund"})
    order = pd.DataFrame({"no_phrase": ~names[mask].str.contains(phrase, regex=False),
                          "length": names[mask].str.len()})
    return schemes.loc[order.sort_values(["no_phrase", "length"]).index].head(limit)


def other_plan(schemes, code):
    """Code of the Regular plan matching a Direct plan (or the reverse), if exactly one matches."""
    row = schemes[schemes["code"] == code]
    if row.empty:
        return None
    match = schemes[(schemes["key"] == row["key"].iat[0]) & (schemes["plan"] != row["plan"].iat[0])]
    return int(match["code"].iat[0]) if len(match) == 1 else None


def fetch_nav(code, cache_dir=None, max_age_hours=12):
    """(meta, nav) for one scheme, where nav is a float Series indexed by date, oldest first.

    With `cache_dir` the raw JSON is kept on disk and reused while it is fresh,
    so repeated research runs don't hit the API again.
    """
    path = Path(cache_dir) / f"{code}.json" if cache_dir else None
    if path and path.exists() and time.time() - path.stat().st_mtime < max_age_hours * 3600:
        payload = json.loads(path.read_text(encoding="utf-8"))
    else:
        payload = get_json(f"{API}/{code}")
        if not payload.get("data"):
            raise ValueError(f"mfapi.in returned no NAVs for scheme {code}")
        if path:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(payload), encoding="utf-8")
    return payload["meta"], parse_nav(payload["data"])


def parse_nav(rows):
    df = pd.DataFrame(rows)
    nav = pd.Series(pd.to_numeric(df["nav"], errors="coerce").to_numpy(),
                    index=pd.to_datetime(df["date"], format="%d-%m-%Y"), name="nav")
    nav = nav[nav > 0]
    nav = nav[~nav.index.duplicated()]
    return nav.sort_index()


def data_checks(nav, big_move=0.15):
    """Facts about a series worth knowing before trusting anything computed from it."""
    gaps = nav.index.to_series().diff().dt.days
    moves = nav.pct_change().dropna()
    return {
        "first_nav": nav.index[0],
        "last_nav": nav.index[-1],
        "nav_count": len(nav),
        "longest_gap_days": int(gaps.max()) if len(nav) > 1 else 0,
        "big_moves": moves[moves.abs() > big_move],
    }
