"""Analysis of Indian mutual funds from their published NAV history."""
