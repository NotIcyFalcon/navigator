"""Number formatting shared by the app and the research scripts."""
import math


def _missing(x):
    return x is None or (isinstance(x, float) and math.isnan(x))


def inr(x, decimals=0):
    """Rupees with Indian digit grouping, e.g. ₹4,74,118."""
    if _missing(x):
        return "–"
    sign = "-" if x < 0 else ""
    whole, _, frac = f"{abs(x):.{decimals}f}".partition(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        pairs = []
        while len(head) > 2:
            pairs.insert(0, head[-2:])
            head = head[:-2]
        whole = ",".join([head] + pairs + [tail])
    return f"{sign}₹{whole}" + (f".{frac}" if frac else "")


def pct(x, decimals=2):
    if _missing(x):
        return "–"
    return f"{x * 100:.{decimals}f}%"
