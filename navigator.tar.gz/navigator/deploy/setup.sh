#!/usr/bin/env bash
# Install or update NAVigator on an Ubuntu/Debian server, served over HTTPS by Caddy.
# Needs Python 3.12+ (Ubuntu 24.04 or newer, Debian 13).
#
#   sudo bash deploy/setup.sh yourname.duckdns.org
#
# Safe to run again after uploading a newer copy of the code. If another web
# server already owns ports 80/443, the app is still installed but Caddy is
# left out; see deploy/nginx.conf for proxying to it from nginx instead.
set -euo pipefail

DOMAIN="${1:?usage: sudo bash deploy/setup.sh <name>.duckdns.org}"
SRC="$(cd "$(dirname "$0")/.." && pwd)"
APP=/opt/navigator

if ! python3 -c 'import sys; sys.exit(sys.version_info < (3, 12))'; then
    echo "Needs Python 3.12 or newer (Ubuntu 24.04+, Debian 13). This server has $(python3 --version)." >&2
    exit 1
fi

echo "== packages"
apt-get update -q
apt-get install -y -q python3-venv rsync

# Small (1 GB) machines get a little swap for headroom.
if [ "$(free -m | awk '/^Mem:/ {print $2}')" -lt 2000 ] && [ -z "$(swapon --show)" ]; then
    echo "== adding 1 GB swap"
    fallocate -l 1G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
    echo "/swapfile none swap sw 0 0" >> /etc/fstab
fi

echo "== app"
id -u navigator >/dev/null 2>&1 || useradd --system --home-dir "$APP" --shell /usr/sbin/nologin navigator
mkdir -p "$APP"
rsync -a --delete --exclude .venv --exclude data/cache --exclude __pycache__ "$SRC"/ "$APP"/
[ -x "$APP/.venv/bin/python" ] || python3 -m venv "$APP/.venv"
"$APP/.venv/bin/pip" install -q -r "$APP/requirements.txt"
chown -R navigator:navigator "$APP"
install -m 644 "$APP/deploy/navigator.service" /etc/systemd/system/navigator.service
systemctl daemon-reload
systemctl enable -q navigator
systemctl restart navigator

# Something other than Caddy already serving the web?
others=$(ss -ltnpH '( sport = :80 or sport = :443 )' 2>/dev/null \
    | grep -o 'users:(("[^"]*' | cut -d'"' -f2 | sort -u | grep -vx caddy || true)
if [ -n "$others" ]; then
    echo
    echo "Ports 80/443 are already in use by: $others"
    echo "Caddy was not installed. The app is running on 127.0.0.1:8501; point $DOMAIN"
    echo "at it from that server (deploy/nginx.conf has an nginx example)."
    exit 0
fi

echo "== caddy"
if ! command -v caddy >/dev/null && ! apt-get install -y -q caddy; then
    # Not every release packages Caddy; fall back to the Caddy project's repository.
    apt-get install -y -q debian-keyring debian-archive-keyring apt-transport-https curl gnupg
    curl -1sLf https://dl.cloudsmith.io/public/caddy/stable/gpg.key \
        | gpg --dearmor --yes -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
    curl -1sLf https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt > /etc/apt/sources.list.d/caddy-stable.list
    apt-get update -q
    apt-get install -y -q caddy
fi

CADDYFILE=/etc/caddy/Caddyfile
site=$(sed "s/__DOMAIN__/$DOMAIN/" "$APP/deploy/Caddyfile")
if [ ! -s "$CADDYFILE" ] || grep -q "/usr/share/caddy" "$CADDYFILE"; then
    # Still the placeholder config that ships with the package.
    echo "$site" > "$CADDYFILE"
elif ! grep -qF "$DOMAIN {" "$CADDYFILE"; then
    # Someone else's config: keep it and add this site at the end.
    cp "$CADDYFILE" "$CADDYFILE.bak.$(date +%Y%m%d%H%M%S)"
    printf '\n%s\n' "$site" >> "$CADDYFILE"
fi
caddy validate --adapter caddyfile --config "$CADDYFILE" >/dev/null
systemctl enable -q caddy
systemctl reload caddy 2>/dev/null || systemctl restart caddy

# Oracle Cloud's Ubuntu images reject everything except SSH at the iptables level,
# on top of the cloud firewall. Let web traffic through if that's the case here.
if iptables -S INPUT 2>/dev/null | grep -q -- "-j REJECT"; then
    echo "== opening ports 80 and 443 in iptables"
    for port in 80 443; do
        iptables -C INPUT -p tcp --dport "$port" -j ACCEPT 2>/dev/null \
            || iptables -I INPUT 1 -p tcp --dport "$port" -j ACCEPT
    done
    if command -v netfilter-persistent >/dev/null; then netfilter-persistent save; fi
fi

echo
echo "Done. When $DOMAIN points at this server and ports 80 and 443 are open in the"
echo "cloud provider's firewall, Caddy gets an HTTPS certificate by itself and the app"
echo "is live at https://$DOMAIN"
echo
echo "Logs:   journalctl -u navigator -f      journalctl -u caddy -f"
