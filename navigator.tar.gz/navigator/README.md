# NAVigator

A tool for studying Indian mutual funds from their actual NAV history: trailing and rolling returns, drawdowns, risk-adjusted returns, SIP and lump-sum outcomes after capital gains tax, and how much a Regular plan costs compared with the Direct plan of the same scheme.

All data comes from [mfapi.in](https://www.mfapi.in/), which republishes AMFI's daily NAV file. No API key is needed.

## Finding so far

Across 26 well-known equity schemes, the Direct plan returned a median **0.98 percentage points a year** more than the Regular plan over the ten years to 2 November 2026 (range 0.10 to 1.46). For a ₹10,000 monthly SIP that works out to a median **₹1.26 lakh** more at the end. The two Nifty 50 index funds had by far the smallest gap. The full write-up is in [research/direct-vs-regular.md](research/direct-vs-regular.md).

## What's in the app

- **Returns**: growth of 100, trailing returns, CAGR, volatility, Sharpe, Sortino, max drawdown, calendar-year returns
- **Rolling returns**: every 1, 3, 5 or 7-year holding period in the window, and how often it lost money or trailed the risk-free rate
- **Drawdowns**: how far each fund fell from its peak, and how long recovery took
- **SIP / lump sum**: what an investment would be worth, and what would be left after exit load, STT and capital gains tax (holding period worked out per instalment, with grandfathering for pre-2018 units)
- **Direct vs Regular**: the gap between the two plans of any scheme, and what it means for a SIP
- **Data & method**: data checks for each fund, and every formula and assumption

Any scheme with a recent NAV can be searched and added; up to six are compared at once.

## Running it

```
python -m venv .venv
.venv\Scripts\activate          # macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

Tests and the research script:

```
python -m pytest
python -m research.direct_vs_regular
```

## Hosting it

`deploy/` has what's needed to run the app on a small Ubuntu server (24.04 or newer, Python 3.12+) behind Caddy, which takes care of HTTPS. Copy the project to the server and run:

```
sudo bash deploy/setup.sh yourname.duckdns.org
```

The script installs Python and Caddy, runs the app as a systemd service that listens only on localhost, and puts Caddy in front of it. The domain must already point at the server, and ports 80 and 443 must be open, for the certificate to be issued. Running it again after copying newer code updates the app.

## Layout

```
app.py                     Streamlit app
navigator/
    data.py                fetching NAVs, scheme list, pairing Direct and Regular plans
    metrics.py             returns, rolling returns, volatility, Sharpe, Sortino, drawdowns
    simulate.py            SIP and lump-sum purchases, XIRR
    tax.py                 capital gains tax on redemption, by date
    fmt.py                 rupee and percentage formatting
research/
    direct_vs_regular.py   the Direct vs Regular study
    direct-vs-regular.md   write-up
    funds.csv              schemes in the study
    output/, figures/      results
docs/methodology.md        formulas, tax rules, assumptions
tests/                     unit tests
```

The analysis code in `navigator/` doesn't depend on Streamlit, so it can be used from a notebook or script.

## Testing

The tests use cases worked out by hand: steady-growth series with a known CAGR, a drawdown with known dates, Sharpe and Sortino computed directly with NumPy, the XIRR example from Excel's documentation, and tax cases covering the exemption, short-term gains with exit load, grandfathering, set-off of losses and the July 2024 rate change.

## Limitations

Past returns over particular dates, taken from published NAVs. Tax is modelled only for equity-oriented funds and a resident individual, with no surcharge and no other gains in the year. See [docs/methodology.md](docs/methodology.md) for the full list.

Not investment advice.
