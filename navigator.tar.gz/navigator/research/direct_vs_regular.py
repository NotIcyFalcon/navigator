"""Direct vs Regular: what the distributor's commission has cost, measured from NAVs.

Both plans of a scheme invest in the same portfolio. The only difference is the
expense ratio, so the gap between their NAVs is a clean, observable measure of
what the Regular plan costs the investor.

Run from the repository root:

    python -m research.direct_vs_regular
"""
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

from navigator import data, metrics, simulate  # noqa: E402
from navigator.fmt import inr, pct  # noqa: E402

HERE = Path(__file__).resolve().parent
CACHE = HERE.parent / "data" / "cache"
OUT, FIGS = HERE / "output", HERE / "figures"
YEARS = 10
SIP = 10_000
BLUE, INK, MUTED, GRID, FAINT = "#2a78d6", "#0b0b0b", "#898781", "#e1e0d9", "#c3c2b7"


def compare(d, r):
    """Ten-year comparison of a Direct (d) and Regular (r) NAV series on their common dates."""
    end = d.index[-1]
    start = end - pd.DateOffset(years=YEARS)
    row = {"common_start": d.index[0].date(), "end": end.date()}
    if d.index[0] > start:
        return row
    row["cagr_direct"] = metrics.cagr(d, start, end)
    row["cagr_regular"] = metrics.cagr(r, start, end)
    row["gap"] = row["cagr_direct"] - row["cagr_regular"]
    sip = {k: simulate.outcome(n, simulate.sip_lots(n, SIP, start, end, day=5), end)
           for k, n in [("direct", d), ("regular", r)]}
    row["sip_invested"] = sip["direct"]["invested"]
    row["sip_direct"] = sip["direct"]["value"]
    row["sip_regular"] = sip["regular"]["value"]
    row["sip_shortfall"] = row["sip_direct"] - row["sip_regular"]
    row["shortfall_share"] = row["sip_shortfall"] / row["sip_regular"]
    return row


def yearly_cost(d, r):
    """Growth of the Direct/Regular NAV ratio in each full calendar year.

    If the Regular plan costs f more a year, the ratio grows by about f a year,
    whatever the market did, so this isolates the cost from the returns.
    """
    ratio = (d / r).resample("YE").last()
    out = ratio.pct_change().dropna()
    out.index = out.index.year
    first_full = d.index[0].year + (0 if d.index[0] <= pd.Timestamp(d.index[0].year, 1, 7) else 1)
    last_full = d.index[-1].year if d.index[-1].month == 12 and d.index[-1].day >= 28 else d.index[-1].year - 1
    return out.loc[first_full:last_full]


def main():
    sys.stdout.reconfigure(encoding="utf-8")  # the Windows console default can't print ₹
    OUT.mkdir(exist_ok=True)
    FIGS.mkdir(exist_ok=True)
    funds = pd.read_csv(HERE / "funds.csv")

    rows, yearly = [], {}
    for f in funds.itertuples(index=False):
        _, d = data.fetch_nav(f.direct_code, cache_dir=CACHE)
        _, r = data.fetch_nav(f.regular_code, cache_dir=CACHE)
        both = d.index.intersection(r.index)
        d, r = d.loc[both], r.loc[both]
        for code, n in [(f.direct_code, d), (f.regular_code, r)]:
            moves = data.data_checks(n)["big_moves"]
            if len(moves):
                print(f"  check {code}: {len(moves)} daily moves over 15% -> {list(moves.index.date)}")
        rows.append({"scheme": f.scheme, "category": f.category, **compare(d, r)})
        yearly[f.scheme] = yearly_cost(d, r)

    res = pd.DataFrame(rows)
    res.to_csv(OUT / "direct_vs_regular.csv", index=False, float_format="%.8f")
    annual = pd.DataFrame(yearly)
    annual.to_csv(OUT / "annual_cost_by_year.csv", index_label="year", float_format="%.8f")

    ten = res.dropna(subset=["gap"]).sort_values("gap")
    print(f"\n{len(ten)} of {len(res)} schemes have {YEARS} years of common history, ending {ten['end'].max()}")
    print(f"gap in CAGR: median {pct(ten['gap'].median())}, range {pct(ten['gap'].min())} to {pct(ten['gap'].max())}")
    print(ten.groupby("category")["gap"].median().map(pct).to_string())
    print(f"SIP shortfall: median {inr(ten['sip_shortfall'].median())} "
          f"({pct(ten['shortfall_share'].median(), 1)} of the Regular plan's value), "
          f"range {inr(ten['sip_shortfall'].min())} to {inr(ten['sip_shortfall'].max())}")
    print("\nmedian extra annual cost by calendar year:")
    print(pd.DataFrame({"median": annual.median(axis=1).map(pct), "schemes": annual.count(axis=1)}).to_string())
    print("\n" + ten[["scheme", "category", "cagr_direct", "cagr_regular", "gap", "sip_shortfall"]].to_string())

    plot_gap(ten)
    plot_by_year(annual)


def style(ax):
    for side in ["top", "right"]:
        ax.spines[side].set_visible(False)
    for side in ["left", "bottom"]:
        ax.spines[side].set_color(FAINT)
    ax.tick_params(colors=MUTED, labelcolor=INK, labelsize=9)


def plot_gap(ten):
    fig, ax = plt.subplots(figsize=(8, 7.2), layout="constrained")
    labels = [f"{s}  ·  {c}" for s, c in zip(ten["scheme"], ten["category"])]
    ax.barh(labels, ten["gap"] * 100, color=BLUE, height=0.62)
    med = ten["gap"].median() * 100
    ax.axvline(med, color=MUTED, lw=1, ls=":")
    ax.text(med, len(ten) - 0.3, f" median {med:.2f}", color=MUTED, fontsize=9, va="bottom")
    ax.set_xlabel(f"Direct minus Regular, annualised return over {YEARS} years (percentage points)",
                  color=INK, fontsize=9)
    ax.xaxis.grid(True, color=GRID, lw=0.8)
    ax.set_axisbelow(True)
    style(ax)
    end = ten["end"].max()
    # The title goes on the figure, not the axes: the long scheme labels push the axes right.
    fig.suptitle(f"How much more the Direct plan returned a year, {YEARS} years to {end.day} {end:%b %Y}",
                 x=0.02, ha="left", fontsize=11, color=INK)
    fig.savefig(FIGS / "gap_10y.png", dpi=150)
    plt.close(fig)


def plot_by_year(annual):
    fig, ax = plt.subplots(figsize=(8, 4.2))
    for col in annual:
        ax.plot(annual.index, annual[col] * 100, color=FAINT, lw=1)
    ax.plot(annual.index, annual.median(axis=1) * 100, color=BLUE, lw=2.2, marker="o", ms=4,
            label="median across schemes")
    ax.set_ylabel("percentage points", color=INK, fontsize=9)
    ax.set_xticks(annual.index)
    ax.tick_params(axis="x", rotation=0)
    ax.yaxis.grid(True, color=GRID, lw=0.8)
    ax.set_axisbelow(True)
    ax.set_ylim(bottom=0)
    style(ax)
    ax.legend(frameon=False, fontsize=9, loc="upper right")
    ax.set_title("Extra cost of the Regular plan in each calendar year (grey: individual schemes)",
                 loc="left", fontsize=11, color=INK)
    fig.tight_layout()
    fig.savefig(FIGS / "cost_by_year.png", dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    main()
