# Direct vs Regular plans: what the commission has cost

Data to 2 November 2026. Code: `research/direct_vs_regular.py`. Output: `research/output/`.

## Question

Since January 2013 every mutual fund scheme in India has two plans. The Regular plan is sold through a distributor; the Direct plan is bought straight from the fund house. Both plans invest in the same portfolio, but the Regular plan has a higher expense ratio because it includes the distributor's commission.

How much has that difference actually cost, measured from the NAVs rather than from the stated expense ratios?

## Data and method

- 26 schemes, picked by hand: well-known funds from the main equity categories (flexi cap, large cap, mid cap, small cap, ELSS, value) and two Nifty 50 index funds. All have more than ten years of history in both plans. This is not a random sample, and only schemes that still exist could be included. The list is in `research/funds.csv`.
- Daily NAVs of the growth option of both plans from mfapi.in (AMFI data), keeping only dates on which both plans have a NAV.
- For the ten years to 2 November 2026: the annualised return (CAGR) of each plan, and the final value of a ₹10,000 monthly SIP on the 5th of each month (₹12,00,000 invested), before tax.
- Year by year: how much the ratio Direct NAV ÷ Regular NAV grew in each full calendar year. If the Regular plan costs *f* more a year, the ratio grows by roughly *f* a year whatever the market does, so this separates the cost from the returns.
- Every series was checked for daily moves over 15%, which in a diversified fund would point to a data error. None were found.

## Results

**Over ten years the Direct plan returned a median 0.98 percentage points a year more than the Regular plan of the same scheme.** The gap ranged from 0.10 points (UTI Nifty 50 Index) to 1.46 points (Axis Small Cap).

The gap in returns is a little larger than the difference in cost. The extra expense is taken out of a balance that keeps growing, so a cost difference *f* shows up in the returns as roughly *f* × (1 + return). With returns around 12–18% a year, a 0.85% cost difference becomes a gap of about 1%. The year-by-year figures further down measure the cost itself.

![Gap in annualised return, Direct minus Regular, by scheme](figures/gap_10y.png)

By category:

| Category | Schemes | Median gap (pp a year) |
|---|---:|---:|
| Index (Nifty 50) | 2 | 0.15 |
| Value | 1 | 0.74 |
| Flexi cap | 5 | 0.89 |
| Large cap | 6 | 0.95 |
| Mid cap | 3 | 1.05 |
| ELSS | 4 | 1.18 |
| Small cap | 5 | 1.20 |

The two index funds stand apart: their Regular plans cost only 0.1 to 0.2 points more, against roughly 0.7 to 1.5 points for the actively managed schemes. Among active funds the gap tends to be higher for small cap and ELSS schemes, though with three to six schemes per category that is a pattern, not a result.

**In rupees the gap compounds.** On a ₹10,000 monthly SIP over the same ten years, the Direct plan ended a median ₹1,26,292 ahead, which is 5.5% more than the Regular plan's final value. The difference ranged from ₹12,658 (UTI Nifty 50 Index) to ₹2,57,591 (Axis Small Cap).

**The yearly cost has come down a little since 2019.** The median rose from 0.70% in 2014 to about 1.0% in 2016–2018, and has stayed between 0.82% and 0.92% every year since 2019 (0.82% in 2025). The fall in 2019 lines up with SEBI's changes in late 2018: upfront commissions were banned from 22 October 2018, and lower expense-ratio limits for equity schemes took effect on 1 April 2019. This data can only show that the timing matches, not that those changes caused it. (2014 and 2015 include 24 and 25 schemes; some plans started later.)

![Extra cost of the Regular plan in each calendar year](figures/cost_by_year.png)

Full results, ten years to 2 November 2026, before tax:

| Scheme | Category | CAGR, Direct | CAGR, Regular | Gap (pp a year) | SIP shortfall |
|---|---|---:|---:|---:|---:|
| Axis Small Cap | Small cap | 18.40% | 16.93% | 1.46 | ₹2,57,591 |
| Mirae Asset ELSS Tax Saver | ELSS | 15.96% | 14.54% | 1.41 | ₹1,81,786 |
| Axis Midcap | Mid cap | 17.16% | 15.80% | 1.36 | ₹2,09,028 |
| Canara Robeco ELSS Tax Saver | ELSS | 14.62% | 13.40% | 1.22 | ₹1,73,119 |
| Axis Large Cap | Large cap | 12.58% | 11.36% | 1.22 | ₹1,25,379 |
| SBI Small Cap | Small cap | 17.20% | 16.00% | 1.20 | ₹1,78,886 |
| HDFC Small Cap | Small cap | 16.73% | 15.54% | 1.20 | ₹1,69,709 |
| DSP ELSS Tax Saver | ELSS | 14.42% | 13.29% | 1.13 | ₹1,47,237 |
| Mirae Asset Large Cap | Large cap | 12.43% | 11.34% | 1.09 | ₹1,26,075 |
| Nippon India Small Cap | Small cap | 19.58% | 18.50% | 1.09 | ₹1,91,696 |
| Kotak Flexi Cap | Flexi cap | 12.99% | 11.92% | 1.07 | ₹1,22,988 |
| DSP Midcap | Mid cap | 13.30% | 12.25% | 1.05 | ₹1,36,987 |
| Nippon India Large Cap | Large cap | 14.09% | 13.08% | 1.01 | ₹1,26,508 |
| Axis ELSS Tax Saver | ELSS | 11.96% | 11.01% | 0.95 | ₹98,465 |
| Franklin India Flexi Cap | Flexi cap | 13.12% | 12.18% | 0.94 | ₹1,14,727 |
| DSP Small Cap | Small cap | 15.81% | 14.89% | 0.92 | ₹1,70,771 |
| Parag Parikh Flexi Cap | Flexi cap | 16.83% | 15.94% | 0.89 | ₹1,40,065 |
| SBI Large Cap | Large cap | 11.81% | 10.92% | 0.89 | ₹95,050 |
| HDFC Mid Cap | Mid cap | 16.54% | 15.67% | 0.87 | ₹1,33,624 |
| HDFC Flexi Cap | Flexi cap | 15.63% | 14.84% | 0.79 | ₹1,14,458 |
| ICICI Prudential Large Cap | Large cap | 13.33% | 12.57% | 0.76 | ₹85,830 |
| ICICI Prudential Value | Value | 14.27% | 13.54% | 0.74 | ₹92,327 |
| UTI Flexi Cap | Flexi cap | 11.93% | 11.21% | 0.72 | ₹85,409 |
| HDFC Large Cap | Large cap | 12.11% | 11.42% | 0.69 | ₹77,833 |
| HDFC Nifty 50 Index | Index (Nifty 50) | 11.63% | 11.44% | 0.19 | ₹21,417 |
| UTI Nifty 50 Index | Index (Nifty 50) | 11.69% | 11.59% | 0.10 | ₹12,658 |

## Caveats

- The gap captures everything that differs between the two NAVs, which is almost entirely the expense ratio. It says nothing about whether the advice that came with a Regular plan was worth the cost. For some investors it may have been.
- The schemes were chosen by hand and all of them survived. That matters less here than in a study of returns, because the gap is about fees rather than performance, but the sample is still not representative of all schemes.
- Ten-year numbers depend on the end date. The year-by-year view depends on it much less.
- The figures are before tax. Tax narrows the rupee gap a little, because the Regular plan's smaller gain attracts less capital gains tax.

## Reproducing

```
python -m research.direct_vs_regular
```

This downloads the NAVs (cached in `data/cache/` for 12 hours), rewrites the CSVs in `research/output/` and redraws both figures. The numbers will shift slightly as new NAVs are published.
